declare module '@tensorflow/tfjs-backend-webgl';
declare module '@tensorflow/tfjs-backend-cpu';
